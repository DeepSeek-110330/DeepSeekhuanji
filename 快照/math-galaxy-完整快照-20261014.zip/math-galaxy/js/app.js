import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { renderPlot } from "./plot.js?v=7";
import { StarLayer, makeNebulaTexture, makeSoftGlowTexture } from "./stars.js?v=7";

/* ============================================================
   1. 全局状态
   ============================================================ */
let DATA = null; // knowledge.json 的内容
const nodeById = new Map(); // id -> 节点数据
let dataIndexOf = new Map(); // id -> Points 中的下标
let starLayer = null; // 知识点星体图层
const bgLayers = []; // 背景星尘图层
let linksObject = null; // 合并后的连线
let linkMeta = []; // 每条连线的元信息
let linkBaseColors = null; // 连线的原始颜色

let hoveredIndex = -1;
let selectedIndex = -1;
let activeBranch = null; // 当前筛选的分支，null = 全部
let currentNode = null; // 当前打开的知识点
let currentLang = "zh"; // zh | en  —— 面板语言
let armAngles = []; // 旋臂基础角度（由 computePositions 填充）

/* ============================================================
   2. 加载数据
   ============================================================ */
async function loadData() {
  // no-cache：每次都向服务器校验，保证加了新知识点后刷新就能看到
  const res = await fetch("data/knowledge.json", { cache: "no-cache" });
  DATA = await res.json();
  DATA.nodes.forEach((n) => nodeById.set(n.id, n));
}

/* 固定种子的随机数：保证每次刷新星系布局一致 */
function seededRandom(seed) {
  let a = seed | 0;
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ============================================================
   3. 计算知识点的 3D 位置
      旋臂分布 + 松弛推挤，避免光团重叠
   ============================================================ */
function computePositions() {
  const rnd = seededRandom(9182736);

  const grouped = new Map();
  DATA.nodes.forEach((n) => {
    if (!grouped.has(n.branch)) grouped.set(n.branch, []);
    grouped.get(n.branch).push(n);
  });

  // 只有「已有知识点的分支」才分配到旋臂上，臂角按数量均匀铺开
  const populated = Object.keys(DATA.branches).filter((b) => grouped.has(b));
  const armCount = Math.max(1, populated.length);
  const anchors = new Map();

  // 记录旋臂的基础角度，供背景星尘复用，保证背景与知识点旋臂对齐
  armAngles = populated.map((_, i) => (i / armCount) * Math.PI * 2);

  populated.forEach((branch, arm) => {
    const nodes = grouped.get(branch);
    // 稳定排序，保证布局可复现
    nodes.sort((a, b) => a.level - b.level || (a.id < b.id ? -1 : 1));

    const armAngle = (arm / armCount) * Math.PI * 2;
    const n = nodes.length;

    // 节点多的分支：旋臂更长、扫过的角度更大，避免挤成一团
    const sweep = Math.min(3.6, 2.0 + n * 0.05);
    const radialSpan = 78 + Math.min(46, n * 1.4);

    nodes.forEach((node, i) => {
      // s：沿着旋臂从内到外的位置
      const s = (i + 0.5) / n;
      // 级别只做轻微的内外偏移，不主导布局
      const lvlShift = (node.level - 3) * 2.6;

      const radius = 30 + s * radialSpan + lvlShift + (rnd() - 0.5) * 7;
      // 旋臂：角度随 s 推进，叠加轻微的螺旋感
      const angle =
        armAngle + s * sweep + radius * 0.006 + (rnd() - 0.5) * 0.16;

      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const y = (rnd() - 0.5) * 30;

      node.position = { x, y, z };
      anchors.set(node.id, { x, y, z });
    });
  });

  // —— 松弛：互相推开，再轻微拉回旋臂 ——
  const nodes = DATA.nodes;
  const minDist = 7.5;
  const minDist2 = minDist * minDist;

  for (let iter = 0; iter < 110; iter++) {
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i].position;
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j].position;
        let dx = b.x - a.x;
        let dy = b.y - a.y;
        let dz = b.z - a.z;
        const d2 = dx * dx + dy * dy + dz * dz;
        if (d2 < minDist2 && d2 > 1e-6) {
          const d = Math.sqrt(d2);
          const push = ((minDist - d) / d) * 0.5;
          dx *= push;
          dy *= push;
          dz *= push;
          a.x -= dx;
          a.y -= dy;
          a.z -= dz;
          b.x += dx;
          b.y += dy;
          b.z += dz;
        }
      }
    }
    // 拉回锚点，保持旋臂轮廓
    const k = 0.014;
    for (let i = 0; i < nodes.length; i++) {
      const p = nodes[i].position;
      const anc = anchors.get(nodes[i].id);
      p.x += (anc.x - p.x) * k;
      p.y += (anc.y - p.y) * k;
      p.z += (anc.z - p.z) * k;
    }
  }
}

/* ============================================================
   4. 场景初始化
   ============================================================ */
const canvas = document.getElementById("galaxy");
const scene = new THREE.Scene();
// 极轻的雾：只用于让远处的连线淡入背景，成本极低
scene.fog = new THREE.FogExp2(0x04050e, 0.0016);

const camera = new THREE.PerspectiveCamera(
  50,
  window.innerWidth / window.innerHeight,
  0.5,
  4000
);
camera.position.set(0, 118, 238);

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: false, // 点精灵自带柔边；省下 MSAA 的开销
  alpha: false,
  powerPreference: "high-performance",
  stencil: false,
  depth: true,
});
renderer.setClearColor(0x04050e, 1);

/* 自适应分辨率：性能不足时自动降采样，保证流畅 */
const quality = {
  pr: Math.min(window.devicePixelRatio || 1, 2),
  max: Math.min(window.devicePixelRatio || 1, 2),
  min: 1,
  steps: 0,
  samples: [],
  lastCheck: 0,
};

function applySize() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  renderer.setPixelRatio(quality.pr);
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  const pr = Math.min(quality.pr, 2);
  if (starLayer) starLayer.material.uniforms.uPixelRatio.value = pr;
  bgLayers.forEach((l) => (l.material.uniforms.uPixelRatio.value = pr));
}

applySize();

/* 相机飞行的状态（在 OrbitControls 事件里会用到，提前声明） */
let fly = null;
let resumeAutoRotateAt = 0;

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.055;
controls.rotateSpeed = 0.42;
controls.zoomSpeed = 1.0;
controls.panSpeed = 0.7;
controls.screenSpacePanning = false;
controls.minDistance = 18; // 允许贴近星星观察
controls.maxDistance = 700;
controls.autoRotate = true;
controls.autoRotateSpeed = 0.32;

/* 用户一操作就交还完全控制权：中断飞行、暂停自转 */
controls.addEventListener("start", () => {
  fly = null;
  controls.autoRotate = false;
});
controls.addEventListener("end", () => {
  resumeAutoRotateAt = performance.now() + 3500;
});

/* ============================================================
   5. 背景：星云 + 银核 + 远景星壳 + 银盘星尘
   ============================================================ */
function createNebulae() {
  const group = new THREE.Group();

  // 贴近银盘的两片「银河带」：扁长形状，制造银河主体光带
  const bandConfigs = [
    { seed: 7, pos: [-40, -8, 30], scale: [700, 190], rot: 0.55, opacity: 0.10, inner: "#2a1b6e", outer: "#1257b8" },
    { seed: 19, pos: [55, 6, -35], scale: [620, 170], rot: 0.6, opacity: 0.09, inner: "#3a1b6e", outer: "#1b3fa8" },
  ];

  // 外围星云：更饱和的冷色，点缀而非糊成一片
  const configs = [
    { seed: 3,  scale: 400, pos: [-185, -26, 155], rot: 0.4,  opacity: 0.28, inner: "#4a1f9e", outer: "#1b5fd8" },
    { seed: 11, scale: 380, pos: [205, 20, -145],  rot: -0.7, opacity: 0.25, inner: "#6a1f8c", outer: "#1f3fd8" },
    { seed: 23, scale: 300, pos: [90, -28, 215],   rot: 1.2,  opacity: 0.20, inner: "#0b4c86", outer: "#5f36d8" },
    { seed: 41, scale: 290, pos: [-145, 28, -205], rot: -1.6, opacity: 0.18, inner: "#6f2a94", outer: "#1560b0" },
  ];

  const addSprite = (tex, opacity, rot) =>
    new THREE.SpriteMaterial({
      map: tex,
      transparent: true,
      opacity,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: false,
      rotation: rot,
    });

  bandConfigs.forEach((c) => {
    const tex = makeNebulaTexture({ seed: c.seed, inner: c.inner, outer: c.outer, size: 192 });
    const sp = new THREE.Sprite(addSprite(tex, c.opacity, c.rot));
    sp.position.set(c.pos[0], c.pos[1], c.pos[2]);
    sp.scale.set(c.scale[0], c.scale[1], 1);
    sp.renderOrder = -3;
    group.add(sp);
  });

  configs.forEach((c) => {
    const tex = makeNebulaTexture({ seed: c.seed, inner: c.inner, outer: c.outer });
    const sp = new THREE.Sprite(addSprite(tex, c.opacity, c.rot));
    sp.position.set(c.pos[0], c.pos[1], c.pos[2]);
    sp.scale.setScalar(c.scale);
    sp.renderOrder = -3;
    group.add(sp);
  });

  return group;
}

function createCore() {
  const group = new THREE.Group();

  // 内层：紧凑的明亮核心
  const innerTex = makeSoftGlowTexture([
    [0, "rgba(255,255,255,1)"],
    [0.25, "rgba(228,238,255,0.55)"],
    [0.55, "rgba(170,198,255,0.16)"],
    [1, "rgba(120,160,255,0)"],
  ]);
  const inner = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: innerTex,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: false,
    })
  );
  inner.scale.setScalar(26);
  inner.renderOrder = -1;
  group.add(inner);

  // 核球：沿银盘方向铺开的柔光
  const bulgeTex = makeSoftGlowTexture([
    [0, "rgba(214,230,255,0.5)"],
    [0.4, "rgba(150,182,255,0.16)"],
    [1, "rgba(90,120,215,0)"],
  ]);
  const bulge = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: bulgeTex,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      depthTest: false,
    })
  );
  bulge.scale.set(230, 78, 1);
  bulge.position.set(0, 0, 0);
  bulge.renderOrder = -2;
  group.add(bulge);

  return group;
}

function createBackgroundStars() {
  const rnd = seededRandom(424242);
  const group = new THREE.Group();

  // —— 远景星壳：包裹整个场景，旋转时产生宇宙纵深 ——
  const shell = [];
  const N1 = 3600;
  for (let i = 0; i < N1; i++) {
    const u = rnd() * 2 - 1;
    const th = rnd() * Math.PI * 2;
    const r = 760 + rnd() * 560;
    const s = Math.sqrt(Math.max(0, 1 - u * u));
    const tint = rnd();
    let color = "#ffffff";
    if (tint > 0.92) color = "#ffd9a8";
    else if (tint > 0.76) color = "#cfe0ff";
    else if (tint > 0.63) color = "#e6d6ff";
    shell.push({
      position: [Math.cos(th) * s * r, u * r * 0.9, Math.sin(th) * s * r],
      color,
      size: 1.5 + rnd() * 3.0,
      spike: rnd() > 0.988 ? 0.55 : 0,
    });
  }
  const shellLayer = new StarLayer(shell, { opacity: 1, twinkle: 0.10 });
  group.add(shellLayer.object);
  bgLayers.push(shellLayer);

  // —— 银盘星尘：严格沿知识点旋臂分布，塑造银河主体 ——
  const dust = [];
  const N2 = 9000;
  const arms = armAngles.length ? armAngles : [0, Math.PI];
  for (let i = 0; i < N2; i++) {
    const arm = arms[Math.floor(rnd() * arms.length)];
    const t = Math.pow(rnd(), 0.85);
    const r = 16 + t * 165;
    // 与知识点旋臂同一条螺线：angle = arm + 0.038r - 0.93
    const spiral = 0.038 * r - 0.93;
    const jitter = (rnd() - 0.5) * (0.55 - 0.34 * t);
    const angle = arm + spiral + jitter;

    const wob = 3.5 + r * 0.07;
    const tint = rnd();
    let color = "#9fb4ff";
    if (tint > 0.9) color = "#ffd9b0";
    else if (tint > 0.68) color = "#cfe0ff";
    else if (tint > 0.42) color = "#b9a8ff";
    dust.push({
      position: [
        Math.cos(angle) * r + (rnd() - 0.5) * wob,
        (rnd() - 0.5) * (5 + r * 0.03),
        Math.sin(angle) * r + (rnd() - 0.5) * wob,
      ],
      color,
      size: 1.0 + rnd() * 1.9,
      spike: 0,
    });
  }
  const dustLayer = new StarLayer(dust, { opacity: 0.6, twinkle: 0.16 });
  group.add(dustLayer.object);
  bgLayers.push(dustLayer);

  // —— 星系晕：弥散的稀疏微光，让星系外缘自然消散 ——
  const halo = [];
  const N3 = 1400;
  for (let i = 0; i < N3; i++) {
    const th = rnd() * Math.PI * 2;
    const r = 120 + Math.pow(rnd(), 0.8) * 260;
    halo.push({
      position: [
        Math.cos(th) * r,
        (rnd() - 0.5) * 40 * (1 - r / 420),
        Math.sin(th) * r,
      ],
      color: rnd() > 0.5 ? "#8fa8e8" : "#b9a8ff",
      size: 0.9 + rnd() * 1.4,
      spike: 0,
    });
  }
  const haloLayer = new StarLayer(halo, { opacity: 0.4, twinkle: 0.1 });
  group.add(haloLayer.object);
  bgLayers.push(haloLayer);

  return group;
}

/* ============================================================
   6. 知识点之间的连线（合并为一次绘制）
   ============================================================ */
function buildLinks() {
  const positions = [];
  const colors = [];
  linkMeta = [];
  const done = new Set();
  const cA = new THREE.Color();
  const cB = new THREE.Color();
  const SEG = 18;

  DATA.nodes.forEach((node) => {
    (node.links || []).forEach((tid) => {
      const key = node.id < tid ? node.id + "|" + tid : tid + "|" + node.id;
      if (done.has(key)) return;
      done.add(key);

      const target = nodeById.get(tid);
      if (!target) return;

      const a = node.position;
      const b = target.position;
      const mx = (a.x + b.x) / 2;
      const my = (a.y + b.y) / 2 + 3.5;
      const mz = (a.z + b.z) / 2;

      const startVert = positions.length / 3;
      let px = null;
      let py = null;
      let pz = null;

      for (let s = 0; s <= SEG; s++) {
        const t = s / SEG;
        const it = 1 - t;
        const x = it * it * a.x + 2 * it * t * mx + t * t * b.x;
        const y = it * it * a.y + 2 * it * t * my + t * t * b.y;
        const z = it * it * a.z + 2 * it * t * mz + t * t * b.z;
        if (px !== null) positions.push(px, py, pz, x, y, z);
        px = x;
        py = y;
        pz = z;
      }

      const vertCount = positions.length / 3 - startVert;
      cA.set(DATA.branches[node.branch].color);
      cB.set(DATA.branches[target.branch].color);

      for (let v = 0; v < vertCount; v++) {
        const t = vertCount > 1 ? v / (vertCount - 1) : 0;
        // 中段稍亮，两端收敛，连线看起来像能量流
        const shape = 0.45 + 0.55 * Math.sin(Math.PI * t);
        const c = cA.clone().lerp(cB, t);
        colors.push(c.r * shape, c.g * shape, c.b * shape);
      }

      linkMeta.push({
        start: startVert,
        count: vertCount,
        a: node.branch,
        b: target.branch,
      });
    });
  });

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  linkBaseColors = new Float32Array(colors);

  const mat = new THREE.LineBasicMaterial({
    vertexColors: true,
    transparent: true,
    opacity: 0.22,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    fog: true,
  });

  linksObject = new THREE.LineSegments(geo, mat);
  linksObject.renderOrder = 1;
  return linksObject;
}

/** 分支筛选：按需重写连线颜色（成本极低） */
function updateLinkColors() {
  if (!linksObject) return;
  const attr = linksObject.geometry.getAttribute("color");
  const arr = attr.array;
  const dim = 0.05;

  linkMeta.forEach((m) => {
    const on =
      !activeBranch || m.a === activeBranch || m.b === activeBranch;
    const k = on ? 1 : dim;
    for (let v = 0; v < m.count; v++) {
      const i = (m.start + v) * 3;
      arr[i] = linkBaseColors[i] * k;
      arr[i + 1] = linkBaseColors[i + 1] * k;
      arr[i + 2] = linkBaseColors[i + 2] * k;
    }
  });
  attr.needsUpdate = true;
}

/* ============================================================
   7. 知识点星体
   ============================================================ */
function createKnowledgeStars() {
  const items = DATA.nodes.map((n) => ({
    position: [n.position.x, n.position.y, n.position.z],
    color: DATA.branches[n.branch].color,
    size: 7 + n.level * 2.8,
    spike: n.level >= 4 ? 0.95 : n.level === 3 ? 0.55 : n.level === 2 ? 0.22 : 0,
  }));

  starLayer = new StarLayer(items, { opacity: 1, twinkle: 0.16 });
  dataIndexOf = new Map(DATA.nodes.map((n, i) => [n.id, i]));
  return starLayer.object;
}

function refreshHighlights() {
  if (!starLayer) return;
  const values = new Float32Array(starLayer.count);
  if (selectedIndex >= 0) values[selectedIndex] = 0.9;
  if (hoveredIndex >= 0) values[hoveredIndex] = Math.max(values[hoveredIndex], 1.6);
  starLayer.setHighlightArray(values);
}

/* ============================================================
   8. 射线拾取（点击 / 悬停）
   ============================================================ */
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const tooltip = document.createElement("div");
tooltip.id = "tooltip";
document.body.appendChild(tooltip);

function updatePointer(e) {
  pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
  pointer.y = -(e.clientY / window.innerHeight) * 2 + 1;
}

function pick() {
  if (!starLayer) return -1;
  // 拾取半径随视距自适应
  const dist = camera.position.distanceTo(controls.target);
  raycaster.params.Points.threshold = Math.max(1.8, dist * 0.02);
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObject(starLayer.object, false);
  return hits.length ? hits[0].index : -1;
}

canvas.addEventListener("pointermove", (e) => {
  updatePointer(e);
  const idx = pick();
  if (idx !== hoveredIndex) {
    hoveredIndex = idx;
    refreshHighlights();
    canvas.style.cursor = idx >= 0 ? "pointer" : "grab";
  }
  if (idx >= 0) {
    const n = DATA.nodes[idx];
    tooltip.textContent =
      currentLang === "en" && n.titleEn ? n.titleEn : n.title;
    tooltip.style.left = e.clientX + 16 + "px";
    tooltip.style.top = e.clientY + 16 + "px";
    tooltip.style.opacity = "1";
  } else {
    tooltip.style.opacity = "0";
  }
});

let pointerDownPos = null;
canvas.addEventListener("pointerdown", (e) => {
  pointerDownPos = { x: e.clientX, y: e.clientY };
});

canvas.addEventListener("pointerup", (e) => {
  if (!pointerDownPos) return;
  const moved = Math.hypot(
    e.clientX - pointerDownPos.x,
    e.clientY - pointerDownPos.y
  );
  pointerDownPos = null;
  if (moved > 6) return; // 视为拖动，不触发点击

  updatePointer(e);
  const idx = pick();
  if (idx >= 0) openPanel(DATA.nodes[idx].id);
});

/* ============================================================
   9. 详情面板
   ============================================================ */
const panel = document.getElementById("panel");
const panelBranch = document.getElementById("panel-branch");
const panelTitle = document.getElementById("panel-title");
const panelSummary = document.getElementById("panel-summary");
const panelContent = document.getElementById("panel-content");
const panelLinks = document.getElementById("panel-links");

document.getElementById("panel-close").addEventListener("click", closePanel);

document.getElementById("lang-toggle").addEventListener("click", () => {
  currentLang = currentLang === "zh" ? "en" : "zh";
  document.getElementById("lang-toggle").textContent =
    currentLang === "zh" ? "EN" : "中文";
  if (currentNode) openPanel(currentNode.id);
});

function closePanel() {
  panel.classList.add("hidden");
  currentNode = null;
  selectedIndex = -1;
  refreshHighlights();
}

function openPanel(id) {
  const node = nodeById.get(id);
  if (!node) return;
  currentNode = node;
  selectedIndex = dataIndexOf.has(id) ? dataIndexOf.get(id) : -1;
  refreshHighlights();

  const branch = DATA.branches[node.branch];
  const useEn = currentLang === "en";
  panelBranch.textContent = useEn && branch.nameEn ? branch.nameEn : branch.name;
  panelBranch.style.color = branch.color;

  panelTitle.innerHTML =
    node.title +
    (node.titleEn ? `<span class="title-en">${node.titleEn}</span>` : "");
  panelSummary.textContent = useEn
    ? node.summaryEn || node.summary || ""
    : node.summary || "";

  panelContent.innerHTML = buildPanelHTML(node, useEn);

  // 关联知识点
  panelLinks.innerHTML = "";
  const linkIds = node.links || [];
  const valid = linkIds.filter((lid) => nodeById.has(lid));
  if (valid.length) {
    const title = document.createElement("div");
    title.className = "links-title";
    title.textContent = useEn ? "Related topics" : "关联知识点";
    panelLinks.appendChild(title);

    valid.forEach((lid) => {
      const ln = nodeById.get(lid);
      const chip = document.createElement("span");
      chip.className = "link-chip";
      chip.innerHTML = `<span class="dot" style="background:${
        DATA.branches[ln.branch].color
      }"></span>${ln.title}`;
      chip.addEventListener("click", () => {
        openPanel(lid);
        flyTo(lid);
      });
      panelLinks.appendChild(chip);
    });
  }

  panel.classList.remove("hidden");
  renderMath();
  renderNodePlots(node);
  flyTo(id);
}

/* 组装面板 HTML：定义 / 公式 / 表达式 / 性质 / 例题 */
function buildPanelHTML(node, useEn) {
  const parts = [];

  const def = useEn ? node.definitionEn || node.definition : node.definition;
  if (def) {
    parts.push(section(useEn ? "Definition" : "定义", mdToHTML(def)));
  } else if (node.content) {
    parts.push(section(useEn ? "Definition" : "定义", mdToHTML(node.content)));
  }

  if (node.formulas && node.formulas.length) {
    const items = node.formulas
      .map(
        (f) =>
          `<div class="formula-item"><div class="formula-latex">$$${f.latex}$$</div>${
            (useEn ? f.noteEn || f.note : f.note)
              ? `<div class="formula-note">${useEn ? f.noteEn || f.note : f.note}</div>`
              : ""
          }</div>`
      )
      .join("");
    parts.push(section(useEn ? "Key Formulas" : "核心公式", items));
  }

  if (node.expression) {
    const e = node.expression;
    parts.push(
      section(
        useEn ? "Expression" : "表达式",
        `<div class="expr-box"><code>${escapeHTML(e.text || "")}</code>${
          e.symbol ? `<span class="expr-symbol">${escapeHTML(e.symbol)}</span>` : ""
        }</div>${
          (useEn ? e.noteEn || e.note : e.note)
            ? `<div class="formula-note">${escapeHTML(useEn ? e.noteEn || e.note : e.note)}</div>`
            : ""
        }`
      )
    );
  }

  if (node.plot) {
    parts.push(`<div class="plot-wrap" id="plot-wrap-${node.id}"></div>`);
  }

  const props = useEn ? node.propertiesEn || node.properties : node.properties;
  if (props && props.length) {
    const items = props.map((p) => `<li>${mdToHTML(p)}</li>`).join("");
    parts.push(section(useEn ? "Properties" : "性质", `<ul class="prop-list">${items}</ul>`));
  }

  if (node.examples && node.examples.length) {
    const items = node.examples
      .map(
        (ex, i) =>
          `<div class="example"><div class="example-q"><b>${
            useEn ? "Example" : "例"
          } ${i + 1}.</b> ${mdToHTML(ex.problem || "")}</div><div class="example-s">${
            useEn ? "Solution" : "解"
          }：${mdToHTML(ex.solution || "")}</div></div>`
      )
      .join("");
    parts.push(section(useEn ? "Examples" : "例题", items));
  }

  return parts.join("");
}

function section(title, body) {
  return `<div class="panel-section"><div class="section-title">${title}</div>${body}</div>`;
}

function renderNodePlots(node) {
  const wrap = document.getElementById(`plot-wrap-${node.id}`);
  if (wrap) {
    wrap.innerHTML = "";
    renderPlot(node.plot, wrap);
  }
}

function escapeHTML(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// 极简 Markdown：**粗体**、`代码`、换行
function mdToHTML(text) {
  let html = escapeHTML(text);
  html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/`(.+?)`/g, "<code>$1</code>");
  return html;
}

function renderMath() {
  if (window.renderMathInElement) {
    window.renderMathInElement(panelContent, {
      delimiters: [
        { left: "$$", right: "$$", display: true },
        { left: "$", right: "$", display: false },
      ],
      throwOnError: false,
    });
  }
}

/* ============================================================
   10. 相机飞行
   —— 基于时间的缓动，保证一定会结束，不会锁死视角
   ============================================================ */
function flyTo(id) {
  const node = nodeById.get(id);
  if (!node) return;

  const pos = new THREE.Vector3(node.position.x, node.position.y, node.position.z);
  const dir = pos.clone().normalize();
  const offset = dir.multiplyScalar(26).add(new THREE.Vector3(0, 12, 0));

  // 落点必须落在可缩放范围内，否则会被 OrbitControls 推回去
  const minLen = controls.minDistance * 1.25;
  const maxLen = controls.maxDistance * 0.8;
  const len = offset.length();
  if (len < minLen) offset.setLength(minLen);
  else if (len > maxLen) offset.setLength(maxLen);

  fly = {
    fromPos: camera.position.clone(),
    toPos: pos.clone().add(offset),
    fromTarget: controls.target.clone(),
    toTarget: pos.clone(),
    start: performance.now(),
    duration: 900,
  };
  controls.autoRotate = false;
}

function updateFly() {
  if (!fly) {
    if (!controls.autoRotate && performance.now() > resumeAutoRotateAt) {
      controls.autoRotate = true;
    }
    return;
  }

  const t = Math.min(1, (performance.now() - fly.start) / fly.duration);
  // easeInOutCubic
  const e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

  camera.position.lerpVectors(fly.fromPos, fly.toPos, e);
  controls.target.lerpVectors(fly.fromTarget, fly.toTarget, e);

  if (t >= 1) {
    fly = null;
    resumeAutoRotateAt = performance.now() + 2800;
  }
}

/* ============================================================
   11. 图例 + 搜索
   ============================================================ */
function buildLegend() {
  const list = document.getElementById("legend-list");
  // 只显示已有知识点的分支，避免点了没有内容
  const populated = new Set(DATA.nodes.map((n) => n.branch));

  Object.entries(DATA.branches)
    .filter(([key]) => populated.has(key))
    .forEach(([key, b]) => {
      const count = DATA.nodes.filter((n) => n.branch === key).length;
      const li = document.createElement("li");
      li.innerHTML =
        `<span class="dot" style="background:${b.color};box-shadow:0 0 10px ${b.color}"></span>` +
        `<span class="legend-name">${b.name}</span>` +
        `<span class="legend-count">${count}</span>`;
      li.addEventListener("click", () => toggleBranch(key, li));
      list.appendChild(li);
    });
}

/* 知识分支面板的收放 */
function setupLegendToggle() {
  const legend = document.getElementById("legend");
  const toggle = document.getElementById("legend-toggle");
  if (!legend || !toggle) return;

  toggle.addEventListener("click", () => {
    const collapsed = legend.classList.toggle("collapsed");
    toggle.setAttribute("aria-expanded", String(!collapsed));
  });
}

function toggleBranch(key, li) {
  if (activeBranch === key) {
    activeBranch = null;
    document
      .querySelectorAll("#legend li")
      .forEach((el) => el.classList.remove("dimmed"));
  } else {
    activeBranch = key;
    document.querySelectorAll("#legend li").forEach((el) => {
      el.classList.toggle("dimmed", el !== li);
    });
  }
  applyBranchFilter();
}

function applyBranchFilter() {
  DATA.nodes.forEach((n, i) => {
    const visible = !activeBranch || n.branch === activeBranch;
    // 被筛掉的分支降低亮度而不是直接消失，保留银河整体轮廓
    starLayer.setAlphaTarget(i, visible ? 1 : 0.055);
  });
  updateLinkColors();
}

function buildSearch() {
  const input = document.getElementById("search");
  const box = document.getElementById("search-results");

  input.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase();
    if (!q) {
      box.classList.add("hidden");
      return;
    }

    const scored = [];
    DATA.nodes.forEach((n) => {
      const title = n.title.toLowerCase();
      const titleEn = (n.titleEn || "").toLowerCase();
      const summary = (n.summary || "").toLowerCase();
      const tags = (n.tags || []).join(" ").toLowerCase();
      let score = 0;
      if (title === q || titleEn === q) score = 100;
      else if (title.startsWith(q)) score = 80;
      else if (title.includes(q)) score = 60;
      else if (titleEn.includes(q)) score = 45;
      else if (tags.includes(q)) score = 30;
      else if (summary.includes(q)) score = 20;
      if (score > 0) scored.push({ n, score });
    });
    scored.sort((a, b) => b.score - a.score || a.n.level - b.n.level);
    const hits = scored.map((s) => s.n);

    box.innerHTML = "";
    if (!hits.length) {
      box.innerHTML = '<div class="empty">没有找到相关知识点</div>';
    } else {
      hits.forEach((n) => {
        const div = document.createElement("div");
        div.className = "item";
        div.innerHTML =
          `<span class="dot" style="background:${
            DATA.branches[n.branch].color
          }"></span>` +
          `<span class="item-text"><span class="item-title">${n.title}</span>` +
          (n.summary ? `<span class="item-sub">${n.summary}</span>` : "") +
          `</span>`;
        div.addEventListener("click", () => {
          box.classList.add("hidden");
          input.value = "";
          const i = dataIndexOf.get(n.id);
          if (i !== undefined) starLayer.setAlphaTarget(i, 1);
          openPanel(n.id);
        });
        box.appendChild(div);
      });
    }
    box.classList.remove("hidden");
  });

  document.addEventListener("click", (e) => {
    if (!e.target.closest("#search-wrap")) box.classList.add("hidden");
  });
}

/* ============================================================
   12. 动画循环
   ============================================================ */
const clock = new THREE.Clock();
let elapsed = 0;

function monitorPerf(dt) {
  if (dt <= 0) return;
  quality.samples.push(dt);
  if (quality.samples.length > 120) quality.samples.shift();

  const now = performance.now();
  if (now - quality.lastCheck < 2500) return;
  if (quality.samples.length < 60) return;
  quality.lastCheck = now;

  const avg = quality.samples.reduce((a, b) => a + b, 0) / quality.samples.length;
  const fps = 1000 / avg;
  quality.samples.length = 0;

  // 帧率偏低时自动降低渲染分辨率，最多降两级
  if (fps < 45 && quality.pr > quality.min + 0.05 && quality.steps < 2) {
    quality.pr = Math.max(quality.min, quality.pr - 0.5);
    quality.steps++;
    applySize();
    console.info(
      `[银河] 检测到帧率偏低（${fps.toFixed(0)}fps），渲染分辨率降至 ${quality.pr}x`
    );
  }
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(0.05, clock.getDelta());
  elapsed += dt;

  updateFly();
  controls.update();

  if (starLayer) starLayer.update(elapsed, dt);
  for (let i = 0; i < bgLayers.length; i++) bgLayers[i].update(elapsed, dt);

  renderer.render(scene, camera);
  monitorPerf(dt);
}

/* ============================================================
   13. 窗口尺寸
   ============================================================ */
let resizeTimer = null;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(applySize, 80);
});

/* ============================================================
   14. 启动
   ============================================================ */
async function main() {
  await loadData();
  computePositions();

  scene.add(createNebulae());
  scene.add(createCore());
  scene.add(createBackgroundStars());
  scene.add(buildLinks());
  scene.add(createKnowledgeStars());

  buildLegend();
  setupLegendToggle();
  buildSearch();

  // 调试钩子：便于查看渲染统计
  window.__galaxy = {
    renderer,
    scene,
    camera,
    controls,
    starLayer,
    bgLayers,
    getFly: () => fly,
  };

  const loading = document.getElementById("loading");
  loading.classList.add("hidden");
  setTimeout(() => (loading.style.display = "none"), 700);

  animate();
}

main();
