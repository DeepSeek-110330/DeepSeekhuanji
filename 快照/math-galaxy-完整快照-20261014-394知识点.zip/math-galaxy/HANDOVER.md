# 数学知识银河 · 完整交接文档 (HANDOVER)

> **一份自包含的项目快照说明。** 新会话只需要读这一个文件，就能完整恢复项目上下文，
> 不必重新读取 4.1 MB 的 `knowledge.json`（这正是 token 成本的大头）。
>
> 文档版本：2026-10-14 ｜ 数据：394 个知识点 ｜ 源码：v=7

---

## ★ 给下一个 AI 的阅读指引（先看这里）

**你只需要用户一句话**：`读 <路径>/HANDOVER.md，然后继续做 XX`。
用户不必粘贴任何内容——你有文件读取工具，自己读即可。

### 阅读顺序与原则

| 顺序 | 文件 | 何时读 | 大小 |
|---|---|---|---|
| **1** | `HANDOVER.md`（本文件） | **必读，从头读完** | 41 KB |
| 2 | `data/SCHEMA.md` | **要生成新知识点时**必读 | 6 KB |
| 3 | `WORKFLOW.md` | 需要**完整错误目录细节**或**更多脚本**时（本文件第 9、11 节是精简版） | 20 KB |
| 4 | `REPORT.md` | 需要**批次历史**或工程质量细节时 | 8 KB |
| 5 | `README.md` | 基本不用读（它是给人类看的项目介绍，内容与本文件重叠） | 5.6 KB |

### ⚠️ 省 token 的关键：不要读这些

| 不要读 | 原因 |
|---|---|
| `data/knowledge.json`（4.1 MB） | **本文件第 4 节已有全部 394 个知识点的 id + 名称 + 等级**，足够判断"有什么、缺什么"。只有需要精确定位某节点的完整内容时才用脚本定向提取单个节点，**不要整体读入** |
| `data/batch*.json`（53 个，共约 3 MB） | 同上，除非要修改某个批次文件，否则用 `merge.py` 的校验结果代替人工阅读 |
| `js/plot.js`（1802 行） | 除非要**新增图表类型**，否则本文件第 6 节已够用 |
| `js/app.js`（1035 行） | 除非要改**布局或交互**，否则不必读；第 10 节已说明布局算法位置与问题 |

### 需要精确定位某个知识点时的正确做法

```python
import json
d = json.load(open('data/knowledge.json', encoding='utf-8'))
n = next(x for x in d['nodes'] if x['id'] == 'derivative')   # 只取需要的那一个
print(json.dumps(n, ensure_ascii=False, indent=2))
```

### 开工前必须向用户确认的两件事

1. **做什么方向**（例如"拓扑学"/"高中补充"）——本文件第 10 节有遗留清单
2. **是否允许改动布局**——第 10 节说明的布局优化会重新排布所有光点，**用户此前明确要求不要移动已有知识点，必须先问**

---

## 目录

1. [一分钟了解](#1-一分钟了解)
2. [启动与验证](#2-启动与验证)
3. [文件清单](#3-文件清单)
4. [★ 知识点全清单（394 个）](#4-知识点全清单394-个) ← 最有价值，避免重读 JSON
5. [数据格式](#5-数据格式)
6. [绘图引擎参考](#6-绘图引擎参考)
7. [内容生成工作流](#7-内容生成工作流)
8. [硬规则](#8-硬规则)
9. [错误目录（89 处历史教训）](#9-错误目录89-处历史教训)
10. [遗留工作](#10-遗留工作)
11. [常用脚本](#11-常用脚本)

---

## 1. 一分钟了解

**数学知识银河**：3D 星系式数学知识可视化站点。

- 每个知识点 = 银河里的一个光点，按学科分支分布在不同旋臂上
- 点击光点 → 相机飞行 → 右侧面板展开完整内容
- 每个知识点含：**中英双语**的定义、名称、摘要、性质 + 公式（带说明）+ 表达式 + 例题 + **代码实时绘制的配图**
- **纯前端**：HTML + CSS + JavaScript，无后端、无数据库、无构建步骤
- 依赖 CDN 加载 Three.js（3D）与 KaTeX（公式）

**覆盖范围**：小学 → 初中 → 高中（三角）→ 大学（微积分 / 多元微积分 / 复变 / ODE / PDE / 数值分析 / 实变 / 泛函 / 微分几何 / 概率统计 / 向量与张量）→ 研究生（拓扑学 / 复分析）

**当前规模**：394 个知识点、1941 条公式、805 道例题、315 张配图、21 条分支、约 36 万字中文正文。

---

## 2. 启动与验证

```bash
cd math-galaxy
python3 -m http.server 8123
# 浏览器打开 http://localhost:8123
```

> **端口必须用 8123**：浏览器缓存按「协议 + 主机 + 端口」隔离。历史开发都在 8123，
> 换端口会导致 CDN 的 Three.js/KaTeX 重新下载（约 3 MB）。
>
> **不能直接双击 index.html**：浏览器会因 CORS 拦截 `fetch` 读本地 JSON 与 ES 模块。

健康检查：

```bash
curl -s -o /dev/null -w "index %{http_code}\n" http://localhost:8123/index.html
curl -s -o /dev/null -w "data  %{http_code}\n" http://localhost:8123/data/knowledge.json
```

**验证注意**：标签页不可见时浏览器会暂停 `requestAnimationFrame`，此时动画不推进、
逐节点检查会超时。做全量验证前先让标签页可见。

---

## 3. 文件清单

```
math-galaxy/
├── README.md               给人看的项目说明
├── REPORT.md               进度报告（规模、批次记录、质量统计）
├── AGENT.md                接手指南（工作流 + 错误目录 + 脚本）
├── HANDOVER.md             本文件（自包含总览）
├── index.html              页面骨架（79 行）
├── plot-test.html          绘图引擎测试页（开发用）
├── css/style.css           样式（659 行）
├── js/
│   ├── app.js              主逻辑：场景/相机/交互/面板/搜索/布局（1035 行）
│   ├── plot.js             绘图引擎：12 种数学图表（1802 行）
│   └── stars.js            星体渲染：着色器星点 + 星云贴图（330 行）
└── data/
    ├── knowledge.json      ★ 运行时唯一数据（约 4.1 MB，由批次合并）
    ├── batch*.json         53 个批次源文件（每批 4~8 个知识点）
    ├── merge.py            合并 + 校验脚本
    ├── SCHEMA.md           数据格式与绘图规范（生成前必读）
    ├── IDLIST.txt          当前所有合法 id 清单（链接校验用）
    └── merge_backup/       （如存在）合并前的备份
```

**源码合计 3,905 行**：app.js 1035 + plot.js 1802 + stars.js 330 + css 659 + html 79

---

## 4. ★ 知识点全清单（394 个）

> **这一节是新会话恢复上下文的关键。** 有了它就不必读 `knowledge.json`（4.1 MB → 本节约 17 KB，省 99%）。

**总计 394 个知识点，分布在 21 条分支上（23 条已定义，`linear` 与 `number` 仍为空）。**

> 格式：`id` 中文名（L 等级）。等级 1~5，越大越高级、光点越大、离银心越远。

### 4.1 小学基础 `elementary-basics` — Elementary School Basics（30 个）

- `addition-subtraction` 加法和减法（L1）
- `angles-elementary` 角的初步认识与度量（L1）
- `area-volume-units` 面积与体积单位（L1）
- `average-elementary` 平均数（L1）
- `chicken-rabbit` 鸡兔同笼（L1）
- `counting-comparison` 数数与比较大小（L1）
- `figures-motion-elementary` 图形的运动（L1）
- `four-operations-order` 四则运算与运算顺序（L1）
- `large-numbers` 大数与近似数（L1）
- `length-units` 长度单位（L1）
- `letters-for-numbers` 用字母表示数与简易方程（L1）
- `mass-time-units` 质量与时间单位（L1）
- `multiplication-division` 乘法和除法（L1）
- `negative-numbers-elementary` 负数的初步认识（L1）
- `observing-objects` 观察物体（L1）
- `perimeter-elementary` 周长（L1）
- `possibility-elementary` 可能性（L1）
- `rounding-approximation` 四舍五入与近似数（L1）
- `solid-figures-elementary` 认识立体图形（L1）
- `statistics-charts` 统计图表（L1）
- `whole-numbers` 整数的认识与数位（L1）
- `area-elementary` 面积与面积公式（L2）
- `circle-elementary` 圆的周长与面积（L2）
- `decimals-elementary` 小数的意义与运算（L2）
- `factors-multiples` 因数、倍数与质数（L2）
- `fractions-elementary` 分数的意义与运算（L2）
- `operation-laws-elementary` 运算定律与简便计算（L2）
- `percentage-elementary` 百分数（L2）
- `ratio-elementary` 比与比例（L2）
- `solid-volume-elementary` 立体图形的体积（L2）

### 4.2 数与式 `elementary` — Numbers & Expressions（10 个）

- `algebraic-expression` 整式与合并同类项（L1）
- `rational-numbers` 有理数（L1）
- `rational-operations` 有理数的运算（L1）
- `scientific-notation` 科学记数法与近似数（L1）
- `algebraic-fraction` 分式（L2）
- `algebraic-identities` 整式的乘法与乘法公式（L2）
- `factorization` 因式分解（L2）
- `quadratic-radical` 二次根式（L2）
- `real-numbers` 实数（L2）
- `square-cube-root` 平方根与立方根（L2）

### 4.3 平面几何 `plane-geometry` — Plane Geometry（11 个）

- `axial-symmetry` 轴对称（L1）
- `intersecting-lines` 相交线与平行线（L1）
- `lines-angle-basics` 直线、射线、线段与角（L1）
- `central-symmetry-rotation` 旋转与中心对称（L2）
- `congruent-triangles` 全等三角形（L2）
- `parallelogram` 平行四边形（L2）
- `plane-coordinates` 平面直角坐标系（L2）
- `projection-view` 投影与视图（L2）
- `rectangle-rhombus-square` 矩形、菱形与正方形（L2）
- `circle-junior` 圆（L3）
- `similarity` 相似三角形（L3）

### 4.4 代数 `algebra` — Algebra（6 个）

- `linear-equation-junior` 一元一次方程（L1）
- `inequality` 不等式（L2）
- `linear-inequality-junior` 一元一次不等式与不等式组（L2）
- `linear-system-two-variables` 二元一次方程组（L2）
- `polynomial` 多项式（L2）
- `quadratic-equation-junior` 一元二次方程（L2）

### 4.5 函数 `function` — Functions（21 个）

- `domain-range` 函数的定义域与值域（L1）
- `function-concept` 函数的概念（L1）
- `linear-function` 一次函数（L1）
- `function-zeros` 函数的零点（L2）
- `inverse-variation-function` 反比例函数（L2）
- `monotonicity` 函数的单调性（L2）
- `parity` 函数的奇偶性（L2）
- `periodicity` 函数的周期性（L2）
- `power-function` 幂函数（L2）
- `quadratic-function` 二次函数（L2）
- `rational-exponent` 指数与指数幂（L2）
- `change-of-base` 换底公式（L3）
- `composite-function` 复合函数（L3）
- `exponential-equation` 指数方程与不等式（L3）
- `exponential-function` 指数函数（L3）
- `inverse-function` 反函数（L3）
- `logarithm` 对数（L3）
- `logarithmic-function` 对数函数（L3）
- `exponential-growth-decay` 指数增长与衰减模型（L4）
- `logarithmic-equation` 对数方程与不等式（L4）
- `natural-constant-e` 自然常数 e 与自然对数（L4）

### 4.6 三角 `trigonometry` — Trigonometry（23 个）

- `triangle` 三角形（L1）
- `acute-trigonometry` 锐角三角函数（L2）
- `angle-radian` 任意角与弧度制（L2）
- `pythagorean` 勾股定理与三角（L2）
- `triangle-area` 三角形的面积（L2）
- `unit-circle` 单位圆（L2）
- `cosine-function` 余弦函数（L3）
- `fundamental-identities` 同角三角函数关系（L3）
- `law-of-cosines` 余弦定理（L3）
- `law-of-sines` 正弦定理（L3）
- `reduction-formulas` 诱导公式（L3）
- `sine-function` 正弦函数（L3）
- `tangent-function` 正切函数（L3）
- `trigonometric-definition` 三角函数的定义（L3）
- `auxiliary-angle` 辅助角公式（L4）
- `inverse-trig-functions` 反三角函数（L4）
- `sinusoidal-model` 正弦型函数模型（L4）
- `triangle-application` 解三角形的实际应用（L4）
- `triangle-identities` 三角形中的恒等变换（L4）
- `trig-properties` 三角函数的性质（L4）
- `trig-transform` 三角函数图像变换（L4）
- `trigonometric-identities` 三角恒等变换（L4）
- `sum-to-product` 和差化积与积化和差（L5）

### 4.7 数列与级数 `sequence` — Sequences & Series（7 个）

- `harmonic-series` 调和级数（L4）
- `series` 无穷级数（L4）
- `alternating-series` 交错级数与绝对收敛（L5）
- `fourier-series` 傅里叶级数（L5）
- `power-series` 幂级数（L5）
- `series-convergence-tests` 正项级数及其判别法（L5）
- `taylor-series` 泰勒级数（L5）

### 4.8 解析几何 `analytic` — Analytic Geometry（1 个）

- `parabola` 抛物线（L2）

### 4.9 微积分 `calculus` — Calculus（33 个）

- `continuity` 函数的连续性（L3）
- `infinitesimal` 无穷小与无穷大（L3）
- `limit` 极限（L3）
- `limit-laws` 极限的运算法则（L3）
- `sequence-limit` 数列极限（L3）
- `antiderivative` 不定积分（L4）
- `chain-rule` 链式法则（L4）
- `concavity-inflection` 凹凸性与拐点（L4）
- `continuity-theorems` 闭区间上连续函数的性质（L4）
- `curve-sketching` 函数图像的描绘（L4）
- `derivative` 导数（L4）
- `differential` 微分（L4）
- `differentiation-rules` 求导法则（L4）
- `discontinuity-types` 间断点及其分类（L4）
- `fundamental-theorem` 微积分基本定理（L4）
- `higher-order-derivative` 高阶导数（L4）
- `integral` 定积分（L4）
- `integral-area` 定积分求面积（L4）
- `integral-physics` 定积分的物理应用（L4）
- `integral-volume` 定积分求体积（L4）
- `integration-by-parts` 分部积分法（L4）
- `integration-substitution` 换元积分法（L4）
- `monotonicity-extremum` 单调性与极值（L4）
- `optimization` 最值问题（L4）
- `two-important-limits` 两个重要极限（L4）
- `arc-length` 弧长（L5）
- `curvature` 曲率（L5）
- `implicit-differentiation` 隐函数求导（L5）
- `improper-integral` 反常积分（L5）
- `lhopital` 洛必达法则（L5）
- `mean-value-theorems` 微分中值定理（L5）
- `parametric-derivative` 参数方程求导（L5）
- `taylor-formula` 泰勒公式（L5）

### 4.10 多元微积分 `multivariable` — Multivariable Calculus（22 个）

- `double-integral` 二重积分（L4）
- `higher-order-partial` 高阶偏导数（L4）
- `multivariable-function` 多元函数（L4）
- `partial-derivative` 偏导数（L4）
- `directional-derivative` 方向导数（L5）
- `divergence-curl` 散度与旋度（L5）
- `double-integral-polar` 极坐标下的二重积分（L5）
- `gauss-theorem` 高斯公式（L5）
- `gradient` 梯度（L5）
- `green-theorem` 格林公式（L5）
- `jacobian` 雅可比行列式（L5）
- `lagrange-multiplier` 拉格朗日乘数法（L5）
- `line-integral` 曲线积分（L5）
- `multivariable-chain-rule` 多元复合函数求导（L5）
- `multivariable-extrema` 多元函数的极值（L5）
- `multivariable-implicit-differentiation` 多元隐函数求导（L5）
- `multivariable-limit` 多元函数的极限与连续（L5）
- `multivariable-taylor` 多元泰勒公式（L5）
- `stokes-theorem` 斯托克斯公式（L5）
- `surface-integral` 曲面积分（L5）
- `total-differential` 全微分（L5）
- `triple-integral` 三重积分（L5）

### 4.11 复变函数与积分变换 `complex` — Complex Analysis & Transforms（27 个）

- `complex-number` 复数（L2）
- `complex-function` 复变函数（L3）
- `complex-plane` 复平面与复数的表示（L3）
- `analytic-function` 解析函数（L4）
- `cauchy-riemann` 柯西-黎曼方程（L4）
- `complex-integral` 复积分（L4）
- `complex-limit-continuity` 复变函数的极限与连续（L4）
- `convolution` 卷积（L4）
- `elementary-complex-functions` 初等复变函数（L4）
- `argument-principle` 辐角原理与儒歇定理（L5）
- `cauchy-integral-formula` 柯西积分公式（L5）
- `cauchy-integral-theorem` 柯西积分定理（L5）
- `complex-power-series` 复幂级数（L5）
- `complex-taylor-series` 复变函数的泰勒级数（L5）
- `fourier-transform` 傅里叶变换（L5）
- `fourier-transform-properties` 傅里叶变换的性质（L5）
- `harmonic-function` 调和函数（L5）
- `inverse-laplace-transform` 拉普拉斯逆变换（L5）
- `isolated-singularities` 孤立奇点（L5）
- `laplace-solve-ode` 用拉普拉斯变换解微分方程（L5）
- `laplace-transform` 拉普拉斯变换（L5）
- `laplace-transform-properties` 拉普拉斯变换的性质（L5）
- `laurent-series` 洛朗级数（L5）
- `liouville-theorem` 刘维尔定理（L5）
- `residue` 留数与留数定理（L5）
- `residue-computation` 留数的计算（L5）
- `residue-real-integrals` 用留数计算实积分（L5）

### 4.12 常微分方程 `ode` — Differential Equations（26 个）

- `ode-basic-concepts` 微分方程的基本概念（L3）
- `bernoulli-equation` 伯努利方程（L4）
- `constant-coefficient-homogeneous` 常系数齐次线性方程（L4）
- `first-order-applications` 一阶微分方程的应用（L4）
- `first-order-linear-ode` 一阶线性微分方程（L4）
- `homogeneous-ode` 齐次方程（L4）
- `reducible-ode` 可降阶的高阶方程（L4）
- `separable-ode` 可分离变量方程（L4）
- `bifurcation-chaos` 分支与混沌初步（L5）
- `constant-coefficient-nonhomogeneous` 常系数非齐次线性方程（L5）
- `dynamical-systems` 动力系统初步：流、轨道与不变集（L5）
- `euler-equation` 欧拉方程（L5）
- `exact-equation` 恰当方程与积分因子（L5）
- `limit-cycles` 极限环与庞加莱-本迪克松定理（L5）
- `linear-ode-system` 线性微分方程组（L5）
- `linear-ode-theory` 高阶线性方程解的结构（L5）
- `lyapunov-second-method` 李雅普诺夫第二方法与李雅普诺夫函数（L5）
- `matrix-exponential` 矩阵指数与基解矩阵（L5）
- `ode-boundary-value` 常微分方程的边值问题（L5）
- `ode-comparison` 比较定理与微分不等式（L5）
- `ode-continuous-dependence` 解对初值与参数的连续依赖性和可微性（L5）
- `ode-existence-uniqueness` 解的存在唯一性定理（L5）
- `ode-maximal-interval` 解的最大存在区间与延拓（L5）
- `ode-power-series` 幂级数解法（L5）
- `phase-plane` 相平面与平衡点（L5）
- `stability` 稳定性理论（L5）

### 4.13 偏微分方程 `pde` — Partial Differential Equations（14 个）

- `pde-basic-concepts` 偏微分方程的基本概念（L4）
- `classification-pde` 二阶线性偏微分方程的分类（L5）
- `dalembert-formula` 达朗贝尔公式（L5）
- `dirichlet-neumann` 狄利克雷问题与诺伊曼问题（L5）
- `first-order-pde` 一阶偏微分方程与特征线法（L5）
- `fourier-method-pde` 傅里叶级数解法（L5）
- `green-function` 格林函数（L5）
- `heat-equation` 热传导方程（L5）
- `laplace-equation` 拉普拉斯方程（L5）
- `maximum-principle` 最大值原理（L5）
- `pde-well-posedness` 定解问题的适定性（L5）
- `separation-of-variables` 分离变量法（L5）
- `sturm-liouville` 施图姆-刘维尔问题（L5）
- `wave-equation` 波动方程（L5）

### 4.14 数值分析 `numerical` — Numerical Analysis（15 个）

- `numerical-error` 误差、有效数字与数值稳定性（L3）
- `direct-linear-solvers` 线性方程组的直接解法：高斯消元与 LU 分解（L4）
- `euler-methods` 欧拉法与改进欧拉法（L4）
- `interpolation` 插值法：拉格朗日插值与牛顿插值（L4）
- `least-squares-fitting` 最小二乘拟合（L4）
- `newton-method` 牛顿迭代法与割线法（L4）
- `nonlinear-equations` 非线性方程求根：二分法与不动点迭代（L4）
- `numerical-differentiation` 数值微分（L4）
- `numerical-integration` 数值积分：梯形公式与辛普森公式（L4）
- `gaussian-quadrature` 高斯求积公式（L5）
- `iterative-linear-solvers` 线性方程组的迭代解法（L5）
- `matrix-condition` 矩阵范数与条件数（L5）
- `numerical-stability` 数值方法的收敛性与稳定性（L5）
- `runge-kutta` 龙格-库塔方法（L5）
- `spline-interpolation` 三次样条插值（L5）

### 4.15 实变函数论 `real-analysis` — Real Analysis（20 个）

- `set-algebra` 集合列与 σ 代数（L3）
- `measurable-functions` 可测函数（L4）
- `measurable-sets` 可测集与勒贝格测度（L4）
- `measure-space` 测度空间与测度的性质（L4）
- `outer-measure` 勒贝格外测度（L4）
- `simple-functions` 简单函数与可测函数的逼近（L4）
- `absolutely-continuous` 绝对连续函数（L5）
- `bounded-variation` 有界变差函数（L5）
- `convergence-ae` 几乎处处收敛与依测度收敛（L5）
- `dominated-convergence` 控制收敛定理（L5）
- `egorov-lusin` 叶戈罗夫定理与鲁津定理（L5）
- `fatou-lemma` 法图引理（L5）
- `fubini-tonelli` 富比尼定理与托内利定理（L5）
- `integral-properties` 勒贝格积分的性质（L5）
- `lebesgue-differentiation` 勒贝格微分定理（L5）
- `lebesgue-integral` 勒贝格积分的定义（L5）
- `lp-spaces` L^p 空间（L5）
- `monotone-convergence` 单调收敛定理（L5）
- `product-measure` 乘积测度（L5）
- `riemann-vs-lebesgue` 黎曼积分与勒贝格积分的关系（L5）

### 4.16 泛函分析 `functional-analysis` — Functional Analysis（18 个）

- `metric-space` 度量空间（L4）
- `normed-space` 赋范线性空间（L4）
- `banach-space` 巴拿赫空间（L5）
- `bounded-operators` 有界线性算子与算子范数（L5）
- `closed-graph` 闭图像定理与一致有界原理（L5）
- `compact-operators` 紧算子（L5）
- `complete-metric-space` 完备度量空间与压缩映射原理（L5）
- `dual-space` 对偶空间与里斯表示定理（L5）
- `fredholm-alternative` 弗雷德霍姆二择一定理（L5）
- `hahn-banach` 哈恩-巴拿赫定理（L5）
- `inner-product-space` 内积空间与希尔伯特空间（L5）
- `open-mapping` 开映射定理与逆算子定理（L5）
- `orthogonality-projection` 正交性与投影定理（L5）
- `orthonormal-basis` 正交基与傅里叶展开（L5）
- `spectral-theorem` 自伴算子的谱定理（L5）
- `spectrum` 谱与预解集（L5）
- `unbounded-operators` 无界算子初步（L5）
- `weak-convergence` 弱收敛与自反空间（L5）

### 4.17 微分几何 `differential-geometry` — Differential Geometry（28 个）

- `arc-length-param` 弧长与弧长参数化（L4）
- `regular-surface` 正则曲面与参数表示（L4）
- `space-curve` 空间曲线与参数表示（L4）
- `surface-area` 曲面的面积（L4）
- `tangent-plane` 切平面与法向量（L4）
- `curvature-torsion` 曲率与挠率（L5）
- `curve-fundamental-theorem` 曲线论基本定理（L5）
- `differential-form` 微分形式（L5）
- `exterior-derivative` 外微分（L5）
- `first-fundamental-form` 第一基本形式（L5）
- `frenet-formulas` Frenet–Serret 公式（L5）
- `frenet-frame` Frenet 标架（L5）
- `gauss-bonnet` 高斯–博内定理（L5）
- `gauss-map` 高斯映射（L5）
- `gaussian-mean-curvature` 高斯曲率与平均曲率（L5）
- `generalized-stokes` 广义斯托克斯定理（L5）
- `geodesic` 测地线（L5）
- `lie-derivative` 李导数与李括号（L5）
- `manifold-integration` 流形上的积分与定向（L5）
- `manifold-vector-fields` 流形上的向量场与流（L5）
- `minimal-surface` 极小曲面（L5）
- `normal-curvature` 法曲率（L5）
- `principal-curvature` 主曲率与主方向（L5）
- `second-fundamental-form` 第二基本形式（L5）
- `smooth-manifold` 光滑流形（L5）
- `surface-isometry` 等距与可展曲面（L5）
- `tangent-space` 切空间与切映射（L5）
- `theorema-egregium` 高斯绝妙定理（L5）

### 4.19 概率统计 `probability` — Probability & Statistics（23 个）

- `data-collection` 数据的收集、整理与描述（L1）
- `data-analysis` 数据的分析（L2）
- `probability-basics` 概率的定义与性质（L2）
- `conditional-probability-bayes` 条件概率与贝叶斯公式（L3）
- `expectation-variance` 数学期望与方差（L3）
- `random-variable` 随机变量与分布函数（L3）
- `statistics-sampling` 总体、样本与统计量（L3）
- `continuous-distributions` 常见连续型分布（L4）
- `covariance-correlation` 协方差与相关系数（L4）
- `discrete-distributions` 常见离散型分布（L4）
- `marginal-conditional-independence` 边缘分布、条件分布与独立性（L4）
- `normal-distribution` 正态分布（L4）
- `random-vector` 二维随机变量与联合分布（L4）
- `regression-analysis` 回归分析（L4）
- `central-limit-theorem` 中心极限定理（L5）
- `chi-square-anova` 卡方检验与方差分析（L5）
- `function-of-random-variables` 随机变量函数的分布（L5）
- `hypothesis-testing` 假设检验（L5）
- `interval-estimation` 区间估计与置信区间（L5）
- `law-of-large-numbers` 大数定律（L5）
- `moments-mgf` 矩与矩母函数（L5）
- `point-estimation` 点估计：矩估计与极大似然（L5）
- `sampling-distributions` 抽样分布与三大分布（L5）

### 4.21 向量与空间 `vector` — Vectors & Space（11 个）

- `vector` 向量（L3）
- `del-operator` 矢量微分算子 ∇（L4）
- `scalar-vector-fields` 标量场与矢量场（L4）
- `christoffel-symbols` Christoffel 符号与协变导数（L5）
- `curvilinear-coordinates` 曲线坐标系中的梯度、散度与旋度（L5）
- `index-notation` 指标记号与爱因斯坦求和约定（L5）
- `metric-tensor` 度量张量与指标升降（L5）
- `stress-strain-tensor` 应力张量与应变张量（L5）
- `tensor-algebra` 张量代数：缩并、对称与反对称（L5）
- `tensor-introduction` 张量初步（L5）
- `vector-identities` 矢量微分恒等式（L5）

### 4.22 拓扑学 `topology` — Topology（24 个）

- `closed-sets-interior` 闭集、闭包与内部（L4）
- `topological-space` 拓扑空间（L4）
- `basis-subbasis` 基与子基（L5）
- `brouwer-fixed-point` 布劳威尔不动点定理（L5）
- `compactness` 紧致性（L5）
- `compactness-metric` 度量空间中的紧致性（L5）
- `connectedness` 连通性与道路连通性（L5）
- `continuity-homeomorphism` 连续映射与同胚（L5）
- `countability-axioms` 可数性公理与可分性（L5）
- `covering-space` 覆叠空间（L5）
- `de-rham-cohomology` 德拉姆上同调（L5）
- `euler-characteristic` 欧拉示性数（L5）
- `fundamental-group` 基本群（L5）
- `fundamental-group-circle` 圆周的基本群（L5）
- `homology-group` 同调群（L5）
- `homotopy` 同伦与同伦等价（L5）
- `local-compactification` 局部紧性与紧化（L5）
- `seifert-van-kampen` 塞弗特–范坎彭定理（L5）
- `separation-axioms` 分离公理（T₀–T₄）（L5）
- `simplicial-complex` 单纯复形与三角剖分（L5）
- `simplicial-homology` 单纯同调群（L5）
- `subspace-product-quotient` 子空间、积空间与商空间（L5）
- `surface-classification` 曲面的分类（L5）
- `tychonoff-theorem` 吉洪诺夫定理（L5）

**主线**：点集拓扑（ZFC 公理 → 连续/同胚 → 子空间·积·商 → 分离公理 T₀–T₄ → 紧 · 连通 · 可数性与可分 → 吉洪诺夫定理 → 局部紧与紧化）→ 代数拓扑（同伦与同伦等价 → 基本群 → π₁(S¹)=ℤ → 覆叠空间 → 塞弗特–范坎彭 → 单纯同调 → 同调群 → 欧拉示性数 → 曲面分类 → 德拉姆上同调，接微分几何的桥梁）。
**性质**：完全无法数值验算，复核只能靠人工逐条审查（本轮 2 个复核代理共抓到 **18 处**错误）。

### 4.23 复分析（专业深度版） `complex-analysis` — Complex Analysis (Graduate Level)（24 个）

- `analytic-continuation` 解析延拓（L5）
- `conformal-mapping` 共形映射（L5）
- `elliptic-functions` 椭圆函数（L5）
- `entire-functions` 整函数（L5）
- `gamma-function` 伽马函数（L5）
- `harmonic-dirichlet-problem` 调和函数与狄利克雷问题（L5）
- `harnack-principle` 哈纳克原理（L5）
- `hyperbolic-geometry-poincare` 双曲几何与庞加莱模型（L5）
- `maximum-modulus-principle` 最大模原理（L5）
- `meromorphic-functions` 亚纯函数（L5）
- `mittag-leffler` 米塔-列夫勒定理（L5）
- `mobius-transformation` 分式线性变换（L5）
- `monodromy-theorem` 单值性定理（L5）
- `normal-families` 正规族与蒙泰尔定理（L5）
- `picard-theorems` 皮卡定理（L5）
- `poisson-integral` 泊松积分公式（L5）
- `residue-advanced` 留数技巧进阶（L5）
- `riemann-mapping-theorem` 黎曼映射定理（L5）
- `riemann-surfaces` 黎曼曲面（L5）
- `schwarz-christoffel` 施瓦茨–克里斯托费尔变换（L5）
- `schwarz-lemma` 施瓦茨引理（L5）
- `uniformization-theorem` 单值化定理（L5）
- `weierstrass-factorization` 魏尔斯特拉斯分解定理（L5）
- `zeta-function` 黎曼 ζ 函数（L5）

**与 `complex` 的分工**：`complex`（27 个）是工科复变与积分变换，本分支不重复其内容，只做数学专业的深化。
**主线**：共形映射与分式线性变换 → 黎曼映射定理 → 施瓦茨引理 → 最大模原理 → 解析延拓 → 单值性定理 → 整函数与增长阶 → 魏尔斯特拉斯分解 → 亚纯函数与米塔-列夫勒 → 皮卡定理 → 正规族与蒙泰尔 → Γ / ζ / 椭圆函数 / SC 变换 / 留数进阶 → 调和函数与狄利克雷问题 → 泊松积分 → 哈纳克原理 → 黎曼曲面 → 单值化定理 → 双曲几何与庞加莱模型。
**性质**：概念性内容为主，复核代理抓到 **20 处**错误（含 2 处经典公式的适用条件被写宽）。



---

## 5. 数据格式

运行时只读 `data/knowledge.json`：

```jsonc
{
  "meta": { "title": "数学知识银河", "version": "2.0" },
  "branches": {
    "calculus": { "name": "微积分", "nameEn": "Calculus", "color": "#d16bff" }
  },
  "nodes": [
    {
      "id": "derivative",              // 全局唯一，小写英文+连字符
      "title": "导数", "titleEn": "Derivative",
      "branch": "calculus",            // 必须是 branches 的键
      "level": 4,                      // 1~5，影响光点大小与离银心距离
      "summary": "…", "summaryEn": "…",
      "definition": "…（支持 **粗体**、`代码`、$行内公式$、$$独立公式$$）",
      "definitionEn": "…",
      "formulas": [{ "latex": "…", "note": "中文说明", "noteEn": "英文说明" }],
      "expression": { "text": "…", "symbol": "…", "note": "…", "noteEn": "…" },
      "properties": ["…"], "propertiesEn": ["…"],   // 中英数量必须一一对应
      "plot": { "type": "function", … },            // 可选，见第 6 节
      "examples": [{ "problem": "…", "solution": "…" }],
      "tags": ["…"],
      "links": ["其他知识点的 id"]                   // 必须真实存在
    }
  ]
}
```

**必填字段**：`id, title, titleEn, branch, level, summary, summaryEn, definition,
definitionEn, formulas, properties, propertiesEn, examples, links`

完整规范见 `data/SCHEMA.md`。

---

## 6. 绘图引擎参考

`js/plot.js` 共 12 种图表类型，全部代码实时绘制、矢量清晰、随窗口缩放：

| type | 用途 | 关键字段 |
|---|---|---|
| `function` | 函数图像 | `functions:[{expr,color,label}]`；`fills`（面积填充）、`tangents`（切线）、`xRange/yRange` |
| `geometry` | 平面几何 | `elements:[{type: polygon/segment/point/label/circle/arc/axes}]` |
| `numberline` | 数轴 | `range`、`points`、`intervals` |
| `unitcircle` | 单位圆与三角函数 | `angle`（弧度） |
| `contour` | 二元函数等值线 | `expr`（用 x,y）、`levels`、`resolution` |
| `vectorfield` | 向量场 / 梯度场 / 相图 | `fx`、`fy`、`contourExpr`（背景等高线）、`marks` |
| `conformal` | 共形映射 | `re`、`im`、`zRange`、`density` |
| `slopefield` | 斜率场 + 解曲线 | `expr`（y'=f(x,y)）、`initial:[{x,y,color,label}]`（自动 RK4 积分画解曲线） |
| `scatter` | 散点图 + 拟合线 | `points`、`lines:[{slope,intercept}]` |
| `quadrature` | 数值积分示意 | `expr`、`from`、`to`、`n`、`method: left/right/midpoint/trapezoid/simpson`（图上自动标近似值） |
| `curve3d` | 3D 曲线 | `x`、`y`、`z`（**变量用 t**）、`tRange`、`frames:[{at}]`（自动算 Frenet 标架画 T/N/B） |
| `surface3d` | 3D 曲面（带光照） | 图形式 `expr`（x,y）；参数式 `surf:{x,y,z}`（**变量用 u,v**）、`uRange/vRange`、`density`、`wire` |

### 表达式求值的坑

1. **变量名固定**：`function/contour/vectorfield/slopefield/scatter` 用 `x`（和 `y`）；`curve3d` 用 `t`；`surface3d` 参数式用 `u,v`
2. **JS 里 `-x**2` 是语法错误** —— 引擎已自动给幂运算底数补括号修复，但新写表达式建议直接写 `-(x^2)`
3. 幂用 `^` 或 `**` 均可；`ln`→`log`、`pi`→`PI`、`e`→`E` 自动转换
4. `xRange` 要避开发散点（如 `sin(1/x)` 在 0 附近）

---

## 7. 内容生成工作流

### 步骤 1：确定范围，先查重

```python
import json
d = json.load(open('data/knowledge.json', encoding='utf-8'))
for n in d['nodes']:
    if n['branch'] == 'calculus': print(n['id'], n['title'])
```

**用户提某个方向时，先扫描已有内容**，明确告知"哪些已有、跳过、新增几个"。避免重复生成。

### 步骤 2：写批次文件 `data/batchNN-<主题>.json`

格式见 `SCHEMA.md`。id 要语义化且全局唯一。

### 步骤 3：更新 `data/IDLIST.txt`

列出所有已有 id + 本批新 id（子代理靠它校验链接）：

```python
import json, textwrap
d = json.load(open('data/knowledge.json', encoding='utf-8'))
existing = [n['id'] for n in d['nodes']]
new = "id1 id2 id3".split()
lines = ["# 所有合法的 links 目标 id（links 只能指向这个列表里的 id，且不能指向自己）", "",
         f"## 已有知识点（{len(existing)} 个）", textwrap.fill(" ".join(existing), 100), "",
         f"## 本批正在生成（{len(new)} 个）", textwrap.fill(" ".join(new), 100)]
open('data/IDLIST.txt','w',encoding='utf-8').write("\n".join(lines)+"\n")
```

### 步骤 4：派生成子代理（**每批 5~7 个知识点**）

提示词必须包含：
1. 必读 `SCHEMA.md` 与 `IDLIST.txt`
2. 输出文件名（**绝对路径**，并强调"只写这个文件"）
3. 知识点清单：`id | 中文名 | 英文名 | level | 配图建议`
4. **本批的准确性硬性要求**（对照第 9 节错误目录，列出该主题的高危点）
5. 字段要求
6. **自检要求**：写完用 python3 检查 JSON 合法/字段齐全/中英数量一致/链接有效/绘图表达式可求值，**并验算每道例题**
7. 回执要求：**≤8 行**，只报路径、节点数、自检结果、修正了什么

> 单批超过 ~8 个知识点质量会掉（实测有代理写到一半崩掉）。

### 步骤 5：合并校验

```bash
cd data && python3 merge.py
```

必须看到 `错误: 0`。常见报错：`id 重复`、`非法 branch`、`未知 plot.type`、`坏链接`。

### 步骤 6：★ 独立复核（**不要省**）

再派 1~3 个**复核代理**（与生成代理分开），逐条重算：

```
你是严格的数学审校员。逐条检查文件的准确性，找出所有真实错误。
【高危点】……（列该主题易错点）
【输出】JSON 数组：{file, id, field, current, problem, fix}
只报确认的真实错误；没有就输出 []。不报格式问题，不复述正确内容。
```

**这不是走过场**：13 轮累计抓到 **89 处真实错误**，平均每轮 6~7 处，且都是
**数值验算抓不到**的类型（定理条件漏写、蕴含方向写反、符号约定不一致）。

### 步骤 7：修正 → 重新合并 → 复检

用**字面替换**修正（不要用正则替换 LaTeX，反斜杠会被当转义）。注意：
- 含 `'` 的字符串用 Python 双引号包（如 `"$y'$"`）
- LaTeX 里 `\m`、`\g` 在正则是非法转义；用字面替换或 `re.escape()`
- 文本里可能有换行，搜索串要包含或避开
- **中英文措辞不同，两处都要改**

### 步骤 8：浏览器验证

抽样打开知识点，确认公式与配图渲染成功；用穷举法把全库公式交给 KaTeX 渲染，
捕获所有警告（应保持 **0 警告**）。脚本见第 11 节。

---

## 8. 硬规则

| 规则 | 说明 |
|---|---|
| **改 JS 必升版本号** | 改 `js/` 下任何文件后，把 `index.html`、`js/app.js`、`plot-test.html` 里的 `?v=N` 统一 +1（当前 **v=7**）。否则浏览器吃旧缓存，你会以为改动没生效 |
| **改数据不用升版本号** | `knowledge.json` 用 `fetch(..., {cache:"no-cache"})` 加载，每次校验，刷新即生效 |
| **加完必跑合并** | `python3 data/merge.py` |
| **生成前先更新 IDLIST** | 否则链接校验失败 |
| **新分支/新图表类型三处同步** | `data/knowledge.json` 的 `branches`、`data/merge.py` 的白名单、`data/SCHEMA.md` |
| **单批 5~7 个** | 超出质量下降 |
| **不擅自改布局** | 用户明确说过不要移动已有知识点（可提议，先问） |

---

## 9. 错误目录（89 处历史教训）

> 生成内容时逐条对照，能避掉大部分坑。

### 9.1 蕴含方向写反（最高频）

| 错误写法 | 正确 |
|---|---|
| 连续必可导 | **可导 ⇒ 连续**，反之不成立 |
| 相关 ⇒ 独立 | **独立 ⇒ 不相关**（ρ=0 推不出独立） |
| 只有独立时 E(XY)=E(X)E(Y) | 独立是充分条件；充要条件是**不相关** |
| a=b ⟺ ac=bc | **c=0 时不成立**；应写 a=b ⟹ ac=bc |
| 闭 ⟺ 闭图像 | 闭图像定理是**图像闭 ⇒ 有界**（不能先设有界） |
| 逐点有界 ⟸ 一致有界 | 一致有界原理是**逐点 ⇒ 一致** |
| 弱收敛 ⇒ 范数收敛 | **范数收敛 ⇒ 弱收敛**，反之不成立 |
| 谱点 ⇒ 特征值 | **特征值 ∈ 谱**，谱点不一定是特征值 |
| 紧算子 ⟸ 有限维 | **恒等算子紧 ⟺ 空间有限维** |
| 闭 ⇒ 恰当 | **恰当 ⇒ 闭**；反向需可缩区域（庞加莱引理） |
| 有 n 位有效数字 ⟺ \|e_r\|≤1/(2a₁)10^{−(n−1)} | 这是**必要**条件；**充分**条件常数是 **1/(2(a₁+1))** |
| 平行 ⇔ 角相等 | **判定（角⇒平行）与性质（平行⇒角）互为逆命题**，方向不能混 |
| 独立 ⟸ 不相关 | **独立 ⇒ 不相关**（方向不能反） |

### 9.2 定理条件漏写/写错

| 定理 | 常被漏掉的条件 |
|---|---|
| 柯西积分定理 | **单连通** + 解析 |
| 乘积测度截面积分公式 | **μ、ν 都 σ 有限** |
| 托内利 vs 富比尼 | 托内利只需 f≥0 可测；富比尼要求 **∫∫\|f\| < ∞** |
| 叶戈罗夫定理 | **有限测度** |
| 控制收敛定理 | **控制函数必须可积** |
| 压缩映射原理 | **完备** + q<1 且与 x,y 无关 |
| 投影定理 | Hilbert 空间（**完备**）+ M 是**闭子空间** |
| Banach–Zaretsky | 需 **连续** + 有界变差 + N 性质 |
| 开映射/闭图像定理 | 需**双巴拿赫空间**；开映射还要**满射** |
| 隐函数定理 | F_z ≠ 0 |
| 牛顿法二阶收敛 | 只在**单根**处；重根退化为线性 |
| Gronwall 引理 | 只需 **β(t) ≥ 0**（α≥0 非必需） |
| 达朗贝尔公式 | ½ 与 1/(2a) 系数、积分区间长 2at |
| 高斯绝妙定理 | 归因于 **Gauss 方程**（不是 Codazzi 方程） |

### 9.3 符号 / 约定不一致

| 问题 | 要点 |
|---|---|
| Frenet 挠率 | τ = (r',r'',r''')/\|r'×r''\|²；**重参数化不变**（变号的是镜像反射，不是 t→−t） |
| 曲面 L、M、N | 符号取决于**法向量取内/外向**，同一文档必须统一 |
| 二阶线性 PDE 判别式 | 是 **B²−AC**（交叉项系数是 2B），不是 B²−4AC |
| 谱半径 | r(T)=lim‖Tⁿ‖^{1/n}；**按绝对值排序**才有 ‖T‖=\|λ₁\| |
| 共轭调和函数 | 关系**不对称**：v 是 u 的共轭，−u 才是 v 的 |
| 中心差商余项 | 是三阶导 **f'''**（不是 f''） |

### 9.4 概念混淆

| 错误 | 正确 |
|---|---|
| "路程 = ∫v dt" | 是**位移**；路程 = ∫\|v\|dt |
| "原点（f_x≠0）是鞍点" | 不是驻点就**不能叫鞍点** |
| "闭而不连续的算子只能定义在**稠密**子空间" | **稠密不是必要条件**（只保证非闭子空间） |
| "无界算子定义域必是稠密真子空间" | 稠密是**约定**，不是定理结论 |
| "鞍结分支是唯一不要求对称性的" | **跨临界分支也不要求** |
| 分数 = "能写成两整数之比" | 那样整数也成了分数，与互斥分类矛盾 |
| "改写 = 去掉末尾 4 个 0" | 是**小数点左移 4 位**；"去末尾 0"只在 0 够多时成立 |
| "线段只有一条对称轴" | **两条**：垂直平分线 + 所在直线 |
| 角平分线逆命题 | 必须限定"**在角的内部**" |
| 高斯映射共形条件 | 需排除**平坦点**（dn=0） |

### 9.5 例证不当 / 答非所问

| 错误 | 正确 |
|---|---|
| 凳子的高约 1 分米 | 1 分米=10cm，凳子约 4 分米；换**粉笔盒** |
| 题问"还需多久"→ 答累计时间 | 要答**剩余时间** |
| 残差平方和 1²+8²+11²=378 | 应为 1²+**16**²+11² |
| 环面 L、N 符号 | 与法向约定不符（该参数化 r_u×r_v 指向内侧） |

### 9.6 工程性坑

| 坑 | 应对 |
|---|---|
| `-x**2` 在 JS 里是语法错误 | 引擎已自动补括号；新表达式写 `-(x^2)` |
| 中文裸露在数学模式 | 包进 `\text{}`（KaTeX 0.16.9 中 `σ` 在 text 模式无字形，用 `\sigma`） |
| 中文下标 `S_{侧}` | 写 `S_{\text{侧}}` |
| 正则替换 LaTeX 报 `bad escape \m` | 用字面替换，或 `re.escape()`；替换串用 `lambda m: new` |
| Python 字符串含 `'` | 用双引号包 |
| 参数曲面用 u,v 但求值器只认 x,y | 用 `buildEvaluator(expr, params, ["u","v"])` |
| 浏览器吃旧缓存 | 改 JS 必升 `?v=N` |
| 标签页后台导致检查超时 | 先 focus 保持可见，或抽样检查 |
| `\,^{\circ}` 被 KaTeX 判错 | 空格类命令（`\,` `\;` `\:` `\!` `\quad`）**不能直接加角标**：`\,^{\circ}` 在页面上渲染成红色错误，必须写 `\,{}^{\circ}`（本轮在旧内容里抓到 5 处） |

### 9.7 拓扑学专属坑（本轮新增 18 处）

| 坑 | 正确写法 |
|---|---|
| 开集公理写反 | 开集：**任意**并 + **有限**交；闭集：**任意**交 + **有限**并（对偶，最容易颠倒） |
| 「紧 ⇒ 闭」漏 Hausdorff | 必须 Hausdorff。**T₁ 不够**：无限集上的余有限拓扑是 T₁，但无限真子集紧而不闭（Sierpiński 空间同理） |
| 道路连通与连通的方向 | 道路连通 ⇒ 连通，**反之不成立**（拓扑学家的正弦曲线）；局部道路连通时两者才一致 |
| 可分与第二可数的关系 | C₂ ⇒ 可分，但**可分 ⇏ C₂**（Sorgenfrey 直线）；只有**度量空间**里 可分 ⟺ C₂ ⟺ Lindelöf |
| 「单点紧化不紧」 | 单点紧化**恒为紧**（构造拉一下覆盖就得到）；它可能不 Hausdorff（如 ℚ*）。要写「X* 紧 Hausdorff」必须先有「X 局部紧 Hausdorff **且不紧**」 |
| 管引理漏条件 | 管引理必须是「**Y 紧** + {x₀}×Y ⊆ W 开」才有 U∋x₀ 使 U×Y ⊆ W |
| 完全正则当成正规 | 完全正则（Tychonoff）**不蕴含正规**，只保证正则 |
| 直线同伦的条件 | H=(1−t)f+t g 只要求 **Y 凸**；星形域要两步（先各自收缩到星心） |
| 覆叠空间提升看错 | 覆叠 p(t)=e^{2πit} 下，γ(t)=e^{2πit} 的提升是 **t**（即 θ(γ(t))/2π），不是 θ(γ(t)) |
| 覆叠分类定理漏条件 | 子群 ↔ 连通覆叠的 Galois 对应要求底空间**半局部单连通** |
| H₁ 与 π₁ 的关系漏条件 | H₁(X) ≅ π₁(X)/[π₁,π₁] 要求 **X 道路连通** |
| 庞加莱对偶漏条件 | 要求**紧致且无边界**（闭）的定向 n-流形 |
| 非交换例子举错 | 环面 T² 的 π₁=ℤ² 本来交换，不能用来说明「顺序有影响」；要举亏格 ≥ 2 的曲面或 S¹∨S¹ |

### 9.8 复分析专属坑（本轮新增 20 处）

| 坑 | 正确写法 |
|---|---|
| Möbius 分类不排除恒等 | **恒等变换**固定每一点、β=4，会污染「1 或 2 个不动点」「抛物型唯一不动点」的结论，必须加「非恒等」 |
| 「收敛圆 = 自然边界」 | **不成立**：1+z+z²+⋯ = 1/(1−z) 除 z=1 外处处可延拓。真正的例子是缺项级数 Σz^{2ᵏ}（Hadamard 缺项定理） |
| 「阶<1 的整函数必有无穷多零点」 | 需限定**超越**（非多项式）：多项式阶为 0，却只有有限多个零点 |
| 极点聚点当成本性奇点 | tan z 在 ∞ 处、1/sin(1/w) 在 w=0 处，奇点本质是**极点的聚点（非孤立奇点）**，不是本性奇点 |
| 皮卡定理假设放宽 | 必须是**本性奇点**，不能写成「非可去」：极点 1/z 在每个去心邻域内就漏掉无穷多个值 |
| SC 变换指数方向写宽 | 「内角越大指数 α−1 越接近 0」**只在凸顶点（内角<π）成立**；凹顶点内角越大指数越大 |
| SC 变换场强奇性指数 | 场强是导数型量，角点附近 ∼ (z−x_k)^{**α_k−1**}，不是 (z−x_k)^{α_k} |
| 哈纳克不等式与泊松核的对应 | 泊松核被 **(1−r/R)/(1+r/R)** 与其倒数夹住，不是 1±r/R |
| 单值化定理抛物型举例 | 抛物型代表是**柱面** ℂ/ℤ ≅ ℂ*；**有界圆环** {1<|z|<R} 属**双曲型** |
| 「全平面能共形映到圆盘」 | 不能——否则有界整函数为常数（刘维尔）。黎曼映射定理的 **D ≠ ℂ** 是本质条件 |
| 调和函数「是解析函数的实部」 | 只在**单连通区域**整体成立；一般区域只是**局部**成立（u=log|z| 在 ℂ∖{0} 上无共轭） |

---

## 10. 遗留工作

### 内容缺口（数学专业方向，约 106 个）

> **已完成**：拓扑学（24 个，`batch53~56`）、复分析专业深度版（24 个，`batch57~60`），2026-10-14。

| 方向 | 估计 | 备注 |
|---|---|---|
| 随机过程 | ~24 | 马尔可夫链、布朗运动、鞅（测度论版本） |
| 黎曼几何 | ~20 | 流形上的度量、联络、曲率张量（可用 `surface3d` 配图） |
| 调和分析 | ~18 | 傅里叶分析深入、奇异积分、Hardy 空间 |
| PDE 深度版补充 | ~14 | 分布理论（广义函数）、索伯列夫空间 |
| 高中补充 | ~30 | 导数初步、立体几何、排列组合、统计案例 |

**建议顺序**：先做能数值验算的（高中、线代、数论、黎曼几何、调和分析），
纯概念的先留出更多复核轮次。

### 空分支

- `linear` 线性代数（0 个）——内容散落在 `vector` 与 `multivariable`，尚未成体系
- `number` 数论与拓展（0 个）

### 布局优化（用户提出，**尚未实施**）

**问题**：银河看起来不均匀——知识点多的臂密，少的臂（如解析几何 1 个点）拖一条长空弧。

**根因**：`js/app.js` 的 `computePositions()` 里 `sweep = min(3.6, 2.0 + n*0.05)`，
即每条臂扫过 117°~206°，与节点数关系不大。

**建议改法**：改成与节点数成正比，如 `min(3.6, 0.5 + n*0.10)`。
**注意**：会重新排布所有点（内容与分支归属不变），**需先征得用户同意**。

### 已知技术债

- Three.js / KaTeX 走 CDN，离线不可用；国内访问 jsdelivr 可能慢
- 「发文件给别人」时不能双击打开（CORS），需本地服务器或打包成免服务器版

---

## 11. 常用脚本

### 11.1 结构校验

```python
import json
d = json.load(open('data/knowledge.json', encoding='utf-8'))
nodes = d['nodes']; ids = {n['id'] for n in nodes}
REQ = ['id','title','titleEn','branch','level','summary','summaryEn',
       'definition','definitionEn','formulas','properties','propertiesEn','examples','links']
bad = []
for n in nodes:
    for k in REQ:
        if not n.get(k): bad.append(f"{n['id']}:缺{k}")
    if len(n['properties']) != len(n['propertiesEn']): bad.append(f"{n['id']}:性质中英不等")
    for i, f in enumerate(n['formulas']):
        if not all(f.get(k) for k in ('latex','note','noteEn')): bad.append(f"{n['id']}:公式{i}不全")
    for l in n.get('links', []):
        if l not in ids: bad.append(f"{n['id']}:坏链{l}")
print('节点', len(nodes), '| 问题', len(bad), bad[:5])
```

### 11.2 把 `\text{}` 之外的中文包进 `\text{}`

```python
import json, re
CJK = re.compile(r'[\u4e00-\u9fff\u3001\u3002\uff0c\uff1b\uff1a\uff08\uff09]')
TEXTCMD = re.compile(r'\\(text|mathrm|operatorname|mbox)\s*\{')
def wrap(inner):
    out=[]; i=0
    while i < len(inner):
        m = TEXTCMD.match(inner, i)
        if m:
            j=m.end(); dep=1
            while j < len(inner) and dep>0:
                if inner[j]=='{': dep+=1
                elif inner[j]=='}': dep-=1
                j+=1
            out.append(inner[i:j]); i=j; continue
        c=inner[i]
        if CJK.match(c):
            k=i
            while k < len(inner) and CJK.match(inner[k]): k+=1
            out.append(r'\text{'+inner[i:k]+'}'); i=k
        else: out.append(c); i+=1
    return ''.join(out)
def fix(s):
    s = re.sub(r'\$\$([\s\S]+?)\$\$', lambda m: '$$'+wrap(m.group(1))+'$$', s)
    return re.sub(r'\$([^$\n]+?)\$', lambda m: '$'+wrap(m.group(1))+'$', s)
```

### 11.3 KaTeX 全库错误扫描（**首选 `katex-check.html`**）

项目根目录已固化一个扫描页：浏览器打开 `http://localhost:8123/katex-check.html`，
它会读取 `knowledge.json`、把全库每个 `$...$` 片段（当前 43,563 个）用 `throwOnError:true, strict:"warn"` 渲染，
在页面上打印 `SCANNED= / ERRORS= / 前 25 条错误`。**改完内容必跑，要求 ERRORS=0**。

下面的旧内联脚本等价，作为备用：

```javascript
const data = await (await fetch('data/knowledge.json', {cache:'no-cache'})).json();
const el = document.createElement('div');
el.style.cssText = 'position:absolute;left:-9999px'; document.body.appendChild(el);
const bad = [];
const tryRender = (tex, nid) => {
  const w = []; const ow = console.warn; console.warn = () => w.push(1);
  try { katex.render(tex, el, { throwOnError: false }); } catch(e) { w.push(1); }
  console.warn = ow;
  if (w.length) bad.push([nid, tex.slice(0,80)]);
};
function walk(o, nid) {
  if (typeof o === 'string') {
    let t = o;
    for (const m of t.matchAll(/\$\$([\s\S]+?)\$\$/g)) tryRender(m[1], nid);
    t = t.replace(/\$\$[\s\S]+?\$\$/g, '');
    for (const m of t.matchAll(/\$([^$\n]+?)\$/g)) tryRender(m[1], nid);
  } else if (Array.isArray(o)) o.forEach(x => walk(x, nid));
  else if (o && typeof o === 'object') Object.entries(o).forEach(([k,v]) => {
    if (k === 'latex' && typeof v === 'string') tryRender(v, nid); else walk(v, nid);
  });
}
for (const n of data.nodes) walk(n, n.id);
el.remove();
return { warnings: bad.length, list: bad.slice(0,5) };   // 应恒为 0
```

### 11.4 截图银河（绕过 RAF 暂停）

```javascript
const g = window.__galaxy;                     // 页面暴露的调试钩子
g.controls.autoRotate = false;
g.camera.position.set(0, 150, 295); g.controls.target.set(0,0,0); g.controls.update();
g.renderer.render(g.scene, g.camera);          // 手动渲染（不依赖 RAF）
const gl = g.renderer.getContext();
const w = gl.drawingBufferWidth, h = gl.drawingBufferHeight;
const px = new Uint8Array(w*h*4);
gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
// 再翻转到 canvas、缩放、toDataURL 输出
```

调试钩子：`window.__galaxy = { renderer, scene, camera, controls, starLayer, bgLayers, getFly }`

---

## 12. 与用户协作的注意事项

1. **质量优先**——用户反复强调"质量第一"，不要为省 token 跳过独立复核
2. **先核对再生成**——用户提某方向时，先扫描已有内容，明确说清"哪些已有、跳过、新增几个"
3. **诚实汇报**——复核抓到多少错误就报多少，附"错在哪、怎么改"。用户明确欣赏这种透明
4. **不擅自改布局**——可提议，但要先问
5. **省 token 的正确做法**：不读生成的内容（最大开销），只跑脚本校验；让子代理自验；
   要求短回执。但**复核环节不要省**
6. **回复用中文**

---

*本文档由项目开发过程自动沉淀。若与代码/数据不一致，以 `data/knowledge.json` 与 `js/` 下的实际文件为准。*
